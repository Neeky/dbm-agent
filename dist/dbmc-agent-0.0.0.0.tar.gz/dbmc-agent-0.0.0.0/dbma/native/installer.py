



class MySQLInstaller(object):
    """MySQL安装器(负责安装MySQL数据库)
    """
    def extra_install_package(source_file_name,target_dir='/usr/local/'):
        """
        """
        pass
    